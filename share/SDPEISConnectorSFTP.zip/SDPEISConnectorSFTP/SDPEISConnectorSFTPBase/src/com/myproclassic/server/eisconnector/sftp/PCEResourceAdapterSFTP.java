/**
 * File: $RCSfile: SDPEISConnectorSFTPBase/src/com/myproclassic/server/eisconnector/sftp/PCEResourceAdapterSFTP.java $
 *
 * Copyright (c) 2001-2005 by Wincor Nixdorf International GmbH,
 * Heinz-Nixdorf-Ring 1, 33106 Paderborn, Germany
 *
 * This software is the confidential and proprietary information
 * of Wincor Nixdorf. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Wincor Nixdorf."
 */
package com.myproclassic.server.eisconnector.sftp;

import javax.resource.ResourceException;
import javax.resource.spi.ActivationSpec;
import javax.resource.spi.BootstrapContext;
import javax.resource.spi.ResourceAdapter;
import javax.resource.spi.ResourceAdapterInternalException;
import javax.resource.spi.endpoint.MessageEndpointFactory;
import javax.transaction.xa.XAResource;


public class PCEResourceAdapterSFTP extends PCEConfigurationHolderSFTP implements ResourceAdapter
{
    private static final long serialVersionUID = 4780619280451176113L;
    
    /** Bootstrap context. */
    protected BootstrapContext m_bootstrapContext = null;
   // protected Map m_serverMap = new HashMap();

    /**
     * Constructor.
     */
    public PCEResourceAdapterSFTP()
    {
        super();
    }

    /**
     * @see javax.resource.spi.ResourceAdapter#endpointActivation(javax.resource.spi.endpoint.MessageEndpointFactory, javax.resource.spi.ActivationSpec)
     */
    public void endpointActivation(MessageEndpointFactory mef, ActivationSpec as) throws ResourceException
    {
//          PCEFTPReceiverFactory sf = new PCEFTPReceiverFactory(mef, (PCEActivationSpecFTP) as);
//        m_serverMap.put(as, sf);
//        m_bootstrapContext.getWorkManager().startWork(sf);
    }

    /**
     * @see javax.resource.spi.ResourceAdapter#endpointDeactivation(javax.resource.spi.endpoint.MessageEndpointFactory, javax.resource.spi.ActivationSpec)
     */
    public void endpointDeactivation(MessageEndpointFactory mef, ActivationSpec as)
    {
//        ((PCEFTPReceiverFactory) m_serverMap.get(as)).release();
    }

    /**
     * @see javax.resource.spi.ResourceAdapter#stop()
     */
    public void stop()
    {
    }

    /**
     * @see javax.resource.spi.ResourceAdapter#start(javax.resource.spi.BootstrapContext)
     */
    public void start(BootstrapContext bootstrapContext) throws ResourceAdapterInternalException
    {
        m_bootstrapContext = bootstrapContext;
    }

    /**
     * @see javax.resource.spi.ResourceAdapter#getXAResources(javax.resource.spi.ActivationSpec[])
     */
    public XAResource[] getXAResources(ActivationSpec[] arg0) throws ResourceException
    {
        return null;
    }

    /**
     * @return bootstrap context
     */
    public BootstrapContext getBootstrapContext()
    {
        return m_bootstrapContext;
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }
}


/**
 * File: $RCSfile: SDPEISConnectorSFTPBase/src/com/myproclassic/server/eisconnector/sftp/PCEConfigurationHolderSFTP.java $
 *
 * Copyright (c) 2001-2005 by Wincor Nixdorf International GmbH, 
 * Heinz-Nixdorf-Ring 1, 33106 Paderborn, Germany
 * 
 * This software is the confidential and proprietary information
 * of Wincor Nixdorf. You shall not disclose such confidential 
 * information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Wincor Nixdorf."
 */
package com.myproclassic.server.eisconnector.sftp;


import com.myproclassic.server.eisconnector.PCEEISConnectorData;
import com.myproclassic.server.eisconnector.impl.PCEConfigurationHolder;

public class PCEConfigurationHolderSFTP extends PCEConfigurationHolder {
    private static final long serialVersionUID = 6214903453474155821L;

    ///** FTP connection default port */
    public static final Integer SFTP_DEFAULT_PORT = 22;

    public static final String SFTP_DEFAULT_DIRECTORY = "";
    

    /** Tag for {@link PCEEISConnectorData} additionalData Hashtable */
    public static final String SFTP_ADDTAG_FILENAME = "FileName";

    /** Holds a configuration property. */
    private String m_serverName = null;
    /** Holds a configuration property. */
    private Integer m_portNumber = SFTP_DEFAULT_PORT;
    /** Holds a configuration property. */
    private String m_sftpUsername = null;
    /** Holds a configuration property. */
    private String m_sftpPassword = null;
    /** Holds a configuration property. */
    private String m_sftpDirectory = SFTP_DEFAULT_DIRECTORY;

    private Boolean m_SSHAuthentication;

    private String m_SSHKeyPath;

    /**
     * Constructor.
     */
    public PCEConfigurationHolderSFTP() {
        super();
    }

	/** Copy constructor. */
	public PCEConfigurationHolderSFTP(PCEConfigurationHolder other) {
		super(other);

		if (other instanceof PCEConfigurationHolderSFTP) {
			final PCEConfigurationHolderSFTP oth = (PCEConfigurationHolderSFTP) other;
			setServerName(oth.getServerName());
			setPortNumber(oth.getPortNumber());
			setSftpUsername(oth.getSftpUsername());
			setSftpPassword(oth.getSftpPassword());
			setSftpDirectory(oth.getSftpDirectory());
			setSSHAuthentication(oth.getSSHAuthentication());
		}
		resolveProps();
	}

	@Override
	public PCEConfigurationHolder asConfigurationHolder(Object config, boolean forceClone) {
		if (!(config instanceof PCEConfigurationHolder)) {
			return null;
		}
		if (!forceClone && config instanceof PCEConfigurationHolderSFTP && ((PCEConfigurationHolderSFTP) config).isNormalized()) {
			return (PCEConfigurationHolderSFTP) config;
		}
		return new PCEConfigurationHolderSFTP((PCEConfigurationHolder) config);
	}
	
    /**
     * @return Returns the serverName.
     */
    public String getServerName() {
        if (m_serverName == null && getParent() != null)
            return ((PCEConfigurationHolderSFTP) getParent()).getServerName();
        return m_serverName;
    }

    /**
     * @param serverName
     *            The serverName to set.
     */
    public void setServerName(String serverName) {
        if (serverName == null || serverName.trim().length() == 0)
            serverName = null;
        m_serverName = serverName;
    }

    /**
     * @return Returns the portNumber.
     */
    public Integer getPortNumber() {
        if (m_portNumber == null && getParent() != null)
            return ((PCEConfigurationHolderSFTP) getParent()).getPortNumber();
        return m_portNumber;
    }

    /**
     * @param portNumber
     *            The portNumber to set.
     */
    public void setPortNumber(Integer portNumber) {
        m_portNumber = portNumber;
    }

    /**
     * @return Returns the FtpUsername.
     */
    public String getSftpUsername() {
        if (m_sftpUsername == null && getParent() != null)
            return ((PCEConfigurationHolderSFTP) getParent()).getSftpUsername();
        return m_sftpUsername;
    }

    /**
     * @param username
     *            The FtpUsername to set.
     */
    public void setSftpUsername(String username) {
        m_sftpUsername = username;
    }

    /**
     * @return Returns the FtpPassword.
     */
    public String getSftpPassword() {
        if (m_sftpPassword == null && getParent() != null)
            return ((PCEConfigurationHolderSFTP) getParent()).getSftpPassword();
        return m_sftpPassword;
    }

    /**
     * @param password
     *            The FtpPassword to set.
     */
    public void setSftpPassword(String password) {
        m_sftpPassword = password;
    }

    /**
     * @return the ftpDirectory
     */
    public String getSftpDirectory() {
        if (m_sftpDirectory == null && getParent() != null)
            return ((PCEConfigurationHolderSFTP) getParent()).getSftpDirectory();
        return m_sftpDirectory;
    }

    /**
     * @param sftpDirectory
     *            the ftpDirectory to set
     */
    public void setSftpDirectory(String sftpDirectory) {
        m_sftpDirectory = sftpDirectory;
    }

    public Boolean getSSHAuthentication() {
        if (m_SSHAuthentication == null && getParent() != null)
            return ((PCEConfigurationHolderSFTP) getParent()).getSSHAuthentication();
        return m_SSHAuthentication;
    }

    public void setSSHAuthentication(Boolean SSHAuthentication){
        m_SSHAuthentication = SSHAuthentication;
    }

    public String getSSHKeyPath() {
        if (m_SSHKeyPath == null && getParent() != null)
            return ((PCEConfigurationHolderSFTP) getParent()).getSSHKeyPath();
        return m_SSHKeyPath;
    }

    public void setSSHKeyPath(String SSHKeyPath){
        m_SSHKeyPath = SSHKeyPath;
    }

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((getSSHAuthentication() == null) ? 0 : getSSHAuthentication().hashCode());
		result = prime * result + ((getSSHKeyPath() == null) ? 0 : getSSHKeyPath().hashCode());
		result = prime * result + ((getPortNumber() == null) ? 0 : getPortNumber().hashCode());
		result = prime * result + ((getServerName() == null) ? 0 : getServerName().hashCode());
		result = prime * result + ((getSftpDirectory() == null) ? 0 : getSftpDirectory().hashCode());
		result = prime * result + ((getSftpPassword() == null) ? 0 : getSftpPassword().hashCode());
		result = prime * result + ((getSftpUsername() == null) ? 0 : getSftpUsername().hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		PCEConfigurationHolderSFTP other = (PCEConfigurationHolderSFTP) obj;
		if (getSSHAuthentication() == null) {
			if (other.getSSHAuthentication() != null) {
				return false;
			}
		} else if (!getSSHAuthentication().equals(other.getSSHAuthentication())) {
			return false;
		}
		if (getSSHKeyPath() == null) {
			if (other.getSSHKeyPath() != null) {
				return false;
			}
		} else if (!getSSHKeyPath().equals(other.getSSHKeyPath())) {
			return false;
		}
		if (getPortNumber() == null) {
			if (other.getPortNumber() != null) {
				return false;
			}
		} else if (!getPortNumber().equals(other.getPortNumber())) {
			return false;
		}
		if (getServerName() == null) {
			if (other.getServerName() != null) {
				return false;
			}
		} else if (!getServerName().equals(other.getServerName())) {
			return false;
		}
		if (getSftpDirectory() == null) {
			if (other.getSftpDirectory() != null) {
				return false;
			}
		} else if (!getSftpDirectory().equals(other.getSftpDirectory())) {
			return false;
		}
		if (getSftpPassword() == null) {
			if (other.getSftpPassword() != null) {
				return false;
			}
		} else if (!getSftpPassword().equals(other.getSftpPassword())) {
			return false;
		}
		if (getSftpUsername() == null) {
			if (other.getSftpUsername() != null) {
				return false;
			}
		} else if (!getSftpUsername().equals(other.getSftpUsername())) {
			return false;
		}
		return true;
	}    
}


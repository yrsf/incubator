/**
 * File: $RCSfile: SDPEISConnectorSFTPBase/src/com/myproclassic/server/eisconnector/sftp/PCEManagedConnectionFactorySFTP.java $
 *
 * Copyright (c) 2001-2005 by Wincor Nixdorf International GmbH,
 * Heinz-Nixdorf-Ring 1, 33106 Paderborn, Germany
 *
 * This software is the confidential and proprietary information
 * of Wincor Nixdorf. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Wincor Nixdorf."
 */
package com.myproclassic.server.eisconnector.sftp;

import java.io.PrintWriter;
import java.lang.reflect.Constructor;
import java.util.Iterator;
import java.util.Set;

import javax.resource.ResourceException;
import javax.resource.spi.ConnectionManager;
import javax.resource.spi.ConnectionRequestInfo;
import javax.resource.spi.ManagedConnection;
import javax.resource.spi.ManagedConnectionFactory;
import javax.resource.spi.ResourceAdapter;
import javax.resource.spi.ResourceAdapterAssociation;
import javax.security.auth.Subject;

import com.myproclassic.server.eisconnector.IPCEEISConnectorErrorCodes;
import com.myproclassic.server.eisconnector.PCEEISConnectorException;
import com.myproclassic.server.eisconnector.PCEEISException;
import com.myproclassic.server.eisconnector.impl.IPCEEISPhysicalConnection;
import com.myproclassic.server.eisconnector.impl.PCEEISConnectionFactory;
import com.myproclassic.server.eisconnector.impl.PCEEISContext;
import com.myproclassic.server.eisconnector.impl.PCEManagedConnection;

public class PCEManagedConnectionFactorySFTP extends PCEConfigurationHolderSFTP implements ManagedConnectionFactory, ResourceAdapterAssociation
{
    private static final long serialVersionUID = 91784403974733023L;

    /**
     * Version control.
     * @excludeMember
     */
    public transient static final String PCE_VERSION_CONTROL = 
		"@(#) $RCSfile: SDPEISConnectorSFTPBase/src/com/myproclassic/server/eisconnector/sftp/PCEManagedConnectionFactorySFTP.java $, $Revision: 1.1 $, $Date: 2014/11/27 11:07:31MEZ $";

    /** Holds the association */
    protected ResourceAdapter m_resourceAdapter = null;

    /**
     * Constructor.
     */
    public PCEManagedConnectionFactorySFTP()
    {
        super();
        m_id = "" + super.hashCode();
        m_context = PCEEISContext.getInstance(m_id);
        getManagedConnectionMetaData().setEISProductName("PC/E EIS Connector SFTP");
        getManagedConnectionMetaData().setEISProductVersion("1.1");
        getManagedConnectionMetaData().setMaxConnections(1);
        getManagedConnectionMetaData().setUserName("");
    }
    
    /**
     * @see java.lang.Object#equals(java.lang.Object)
     */
    public boolean equals(Object other)
    {
        if (other == null || !(other instanceof PCEManagedConnectionFactorySFTP))
            return false;

        PCEManagedConnectionFactorySFTP othermcf = (PCEManagedConnectionFactorySFTP) other;
        if (!this.m_id.equals(othermcf.m_id))
            return false;
        //		if (this.m_portNumber != othermcf.m_portNumber) return false;
        //		if (!this.m_serverName.equals(othermcf.m_serverName)) return false;
        return true;
    }

    /**
     * @see javax.resource.spi.ManagedConnectionFactory#createConnectionFactory(javax.resource.spi.ConnectionManager)
     */
    public Object createConnectionFactory(ConnectionManager connectionManager) throws ResourceException
    {
    	return new PCEEISConnectionFactory(this, this, connectionManager);
    }

    /**
     * @see javax.resource.spi.ManagedConnectionFactory#createConnectionFactory()
     */
    public Object createConnectionFactory() throws ResourceException
    {
    	return createConnectionFactory(null);
    }

    static String getPhysicalConnectionClassName(String protocol)
    {
        return "com.myproclassic.server.eisconnector.sftp.PCESFTPConnection";
    }

    /**
     * @see javax.resource.spi.ManagedConnectionFactory#createManagedConnection(javax.security.auth.Subject, javax.resource.spi.ConnectionRequestInfo)
     */
    public ManagedConnection createManagedConnection(Subject subject, ConnectionRequestInfo connectionRequestInfo) throws ResourceException
    {
    	if (getContext().getTrace().isTrace())
    	{
    		getContext().getTrace().traceMethodEntry(this, "createManagedConnection", null);
    	}
    	PCEManagedConnection result = null;
        ClassLoader originalClassLoader = null;

        PCEConfigurationHolderSFTP config = this;
        if (connectionRequestInfo instanceof PCEConfigurationHolderSFTP)
        {
            config = (PCEConfigurationHolderSFTP) connectionRequestInfo;
            config.setParent(this);
        }
        
        try
    	{
    		IPCEEISPhysicalConnection con = null;
            String protocol = config.getProtocol();
            Integer connectMode = config.getConnectMode();

    		if ( protocol == null || protocol.equals(""))
    		{
    			if (getContext().getTrace().isTrace())
    			{
    				getContext().getTrace().traceRaw(this, "createManagedConnection", "Protocol property not set.");
    			}
    			protocol = "SFTP";
    			//throw new PCEEISConnectorException(IPCEEISConnectorErrorCodes.PCE_ERR_CONFIGURATION, null, "Protocol property not set");
    		}

    		try
    		{
    			Class implClass = null;
    			if (getClassLoader() != null)
    			{
    				originalClassLoader = Thread.currentThread().getContextClassLoader();
    				Thread.currentThread().setContextClassLoader(getClassLoader());
    				implClass = getClassLoader().loadConnectionClass(getPhysicalConnectionClassName(protocol));
    			}
    			else
    			{
    				implClass = this.getClass().getClassLoader().loadClass(getPhysicalConnectionClassName(protocol));
    			}
    			Constructor constr = implClass.getConstructor(new Class[] {PCEConfigurationHolderSFTP.class});
    			con = (IPCEEISPhysicalConnection) constr.newInstance(new Object[] {config});
    		}
    		catch (Throwable th)
    		{
    			if (getContext().getTrace().isTrace())
    			{
    				getContext().getTrace().traceException(this, "createManagedConnection", th);
    			}
    			throw new PCEEISConnectorException(IPCEEISConnectorErrorCodes.PCE_ERR_CONFIGURATION, th, "Invalid configuration: " + protocol);
    		}
            con.setTimeout(null);
    		con.open();
            con.checkConnection();
            if (connectMode != null && (connectMode.intValue() & CONNECT_MODE_DISCONNECT_ON_CLOSE) != 0)
            {
                con.close();
            }
    		result =  new PCEManagedConnection(subject, connectionRequestInfo, con, config);
    	}
    	catch (PCEEISException e)
    	{
    		ResourceException e1 = new ResourceException(e);
            if (getContext().getTrace().isTrace())
            {
                getContext().getTrace().traceMethodExit(this, "createManagedConnection", "ResourceException");
            }
    		throw e1;
    	}
        finally
        {
            if (originalClassLoader != null)
            {
                Thread.currentThread().setContextClassLoader(originalClassLoader);
            }
        }

    	if (getContext().getTrace().isTrace())
    	{
    		getContext().getTrace().traceMethodExit(this, "createManagedConnection", result);
    	}
    	return result;
    }

    /**
     * @see javax.resource.spi.ManagedConnectionFactory#matchManagedConnections(java.util.Set, javax.security.auth.Subject, javax.resource.spi.ConnectionRequestInfo)
     */
    public ManagedConnection matchManagedConnections(Set connectionSet, Subject subject, ConnectionRequestInfo info) throws ResourceException
    {
        if (info != null && info instanceof PCEConfigurationHolderSFTP)
        {
            ((PCEConfigurationHolderSFTP) info).setParent(this);
        }

        PCEManagedConnection matchedConnection = null;
        
        Iterator it = connectionSet.iterator();
        while (it.hasNext())
        {
            Object obj = it.next();
            if (obj instanceof PCEManagedConnection)
            {
                PCEManagedConnection mc = (PCEManagedConnection) obj;
                ConnectionRequestInfo otherInfo = mc.getConnectionRequestInfo();

                if (info == null && otherInfo == null)
                {
                    matchedConnection = mc;
                    break;
                }
                else if (info != null && info.equals(otherInfo))
                {
                    matchedConnection = mc;
                    break;
                }
                else if (otherInfo != null && otherInfo.equals(info))
                {
                    matchedConnection = mc;
                    break;
                }
            }
        }
        
        if (matchedConnection != null && info != null)
        {
            PCESFTPConnection con = (PCESFTPConnection) matchedConnection.getPhysicalConnection();
            con.updateConfig((PCEConfigurationHolderSFTP) info);
        }
        return matchedConnection;
    }

    /**
     * @see javax.resource.spi.ManagedConnectionFactory#setLogWriter(java.io.PrintWriter)
     */
    public void setLogWriter(PrintWriter logWriter) throws ResourceException
    {
    	getContext().getTrace().setPrintWriter(logWriter);
    }

    /**
     * @see javax.resource.spi.ManagedConnectionFactory#getLogWriter()
     */
    public PrintWriter getLogWriter() throws ResourceException
    {
    	return getContext().getTrace().getPrintWriter();
    }

    public int hashCode()
    {
    	return m_id.hashCode();
    }

    /**
     * @see javax.resource.spi.ResourceAdapterAssociation#setResourceAdapter(javax.resource.spi.ResourceAdapter)
     */
    public void setResourceAdapter(ResourceAdapter resourceAdapter) throws ResourceException
    {
        m_resourceAdapter = resourceAdapter; 
        if (resourceAdapter instanceof PCEResourceAdapterSFTP)
        {
            m_parent = (PCEConfigurationHolderSFTP) resourceAdapter;
        }
    }

    /**
     * @see javax.resource.spi.ResourceAdapterAssociation#getResourceAdapter()
     */
    public ResourceAdapter getResourceAdapter()
    {
        return m_resourceAdapter;
    }


}


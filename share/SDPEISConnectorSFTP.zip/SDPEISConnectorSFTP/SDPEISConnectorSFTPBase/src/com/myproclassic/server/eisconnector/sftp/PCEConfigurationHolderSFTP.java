/**
 * File: $RCSfile: SDPEISConnectorSFTPBase/src/com/myproclassic/server/eisconnector/sftp/PCEConfigurationHolderSFTP.java $
 *
 * Copyright (c) 2001-2005 by Wincor Nixdorf International GmbH, 
 * Heinz-Nixdorf-Ring 1, 33106 Paderborn, Germany
 * 
 * This software is the confidential and proprietary information
 * of Wincor Nixdorf. You shall not disclose such confidential 
 * information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Wincor Nixdorf."
 */
package com.myproclassic.server.eisconnector.sftp;


import com.myproclassic.server.eisconnector.PCEEISConnectorData;
import com.myproclassic.server.eisconnector.impl.PCEConfigurationHolder;
import com.myproclassic.server.eisconnector.impl.PCEResourceAdapterMetaData;
import org.apache.commons.vfs2.FileType;

public class PCEConfigurationHolderSFTP extends PCEConfigurationHolder {
    private static final long serialVersionUID = 6214903453474155821L;

    ///** FTP connection default port */
    public static final Integer SFTP_DEFAULT_PORT = 22;

    public static final String SFTP_DEFAULT_DIRECTORY = "";
    

    /** Tag for {@link PCEEISConnectorData} additionalData Hashtable */
    public static final String SFTP_ADDTAG_FILENAME = "FileName";

    /** Holds a configuration property. */
    protected String m_serverName = null;
    /** Holds a configuration property. */
    protected Integer m_portNumber = SFTP_DEFAULT_PORT;
    /** Holds a configuration property. */
    protected String m_sftpUsername = null;
    /** Holds a configuration property. */
    protected String m_sftpPassword = null;
    /** Holds a configuration property. */
    protected String m_sftpDirectory = SFTP_DEFAULT_DIRECTORY;

    protected Boolean m_SSHAuthentication;

    protected String m_SSHKeyPath;

    /**
     * Constructor.
     */
    public PCEConfigurationHolderSFTP() {
        super();
    }

    /**
     * @return Returns the serverName.
     */
    public String getServerName() {
        if (m_serverName == null && m_parent != null)
            return ((PCEConfigurationHolderSFTP) m_parent).getServerName();
        return m_serverName;
    }

    /**
     * @param serverName
     *            The serverName to set.
     */
    public void setServerName(String serverName) {
        if (serverName == null || serverName.trim().length() == 0)
            serverName = null;
        m_serverName = serverName;
    }

    /**
     * @return Returns the portNumber.
     */
    public Integer getPortNumber() {
        if (m_portNumber == null && m_parent != null)
            return ((PCEConfigurationHolderSFTP) m_parent).getPortNumber();
        return m_portNumber;
    }

    /**
     * @param portNumber
     *            The portNumber to set.
     */
    public void setPortNumber(Integer portNumber) {
        m_portNumber = portNumber;
    }

    /**
     * @return Returns the FtpUsername.
     */
    public String getSftpUsername() {
        if (m_sftpUsername == null && m_parent != null)
            return ((PCEConfigurationHolderSFTP) m_parent).getSftpUsername();
        return m_sftpUsername;
    }

    /**
     * @param username
     *            The FtpUsername to set.
     */
    public void setSftpUsername(String username) {
        m_sftpUsername = username;
    }

    /**
     * @return Returns the FtpPassword.
     */
    public String getSftpPassword() {
        if (m_sftpPassword == null && m_parent != null)
            return ((PCEConfigurationHolderSFTP) m_parent).getSftpPassword();
        return m_sftpPassword;
    }

    /**
     * @param password
     *            The FtpPassword to set.
     */
    public void setSftpPassword(String password) {
        m_sftpPassword = password;
    }

    /**
     * @return the ftpDirectory
     */
    public String getSftpDirectory() {
        if (m_sftpDirectory == null && m_parent != null)
            return ((PCEConfigurationHolderSFTP) m_parent).getSftpDirectory();
        return m_sftpDirectory;
    }

    /**
     * @param sftpDirectory
     *            the ftpDirectory to set
     */
    public void setSftpDirectory(String sftpDirectory) {
        m_sftpDirectory = sftpDirectory;
    }

    public Boolean getSSHAuthentication() {
        if (m_SSHAuthentication == null && m_parent != null)
            return ((PCEConfigurationHolderSFTP) m_parent).getSSHAuthentication();
        return m_SSHAuthentication;
    }


    public void setSSHAuthentication(Boolean SSHAuthentication){
        m_SSHAuthentication = SSHAuthentication;
    }

    public String getSSHKeyPath() {
        if (m_SSHKeyPath == null && m_parent != null)
            return ((PCEConfigurationHolderSFTP) m_parent).getSSHKeyPath();
        return m_SSHKeyPath;
    }

    public void setSSHKeyPath(String SSHKeyPath){
        m_SSHKeyPath = SSHKeyPath;
    }


    public PCEResourceAdapterMetaData getResourceAdapterMetaData() {
        if (m_resourceAdapterMetaData == null) {
            m_resourceAdapterMetaData = new PCEResourceAdapterMetaData();
            m_resourceAdapterMetaData.setAdapterName("PC/E EIS Connector SFTP");
            m_resourceAdapterMetaData.addConfigProperty("Name", getName());
            m_resourceAdapterMetaData.addConfigProperty("Classpath", getClasspath());
            m_resourceAdapterMetaData.addConfigProperty("ConnectMode", getConnectMode());
            m_resourceAdapterMetaData.addConfigProperty("Protocol", getProtocol());
            m_resourceAdapterMetaData.addConfigProperty("UserName", getUserName());

            m_resourceAdapterMetaData.addConfigProperty("ServerName", getServerName());
            m_resourceAdapterMetaData.addConfigProperty("PortNumber", getPortNumber());
            m_resourceAdapterMetaData.addConfigProperty("SFTP UserName", getSftpUsername());
            m_resourceAdapterMetaData.addConfigProperty("SFTP Password", getSftpPassword());
            m_resourceAdapterMetaData.addConfigProperty("SFTP Directory", getSftpDirectory());
            m_resourceAdapterMetaData.addConfigProperty("SFTP SSH Auth", getSSHAuthentication());
            m_resourceAdapterMetaData.addConfigProperty("SFTP SSH KeyPath", getSSHKeyPath());

        }
        return m_resourceAdapterMetaData;
    }

}


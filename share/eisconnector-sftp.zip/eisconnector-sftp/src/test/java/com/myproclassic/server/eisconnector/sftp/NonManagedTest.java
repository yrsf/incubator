package com.myproclassic.server.eisconnector.sftp;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Hashtable;

import com.myproclassic.server.eisconnector.IPCEEISConnection;
import com.myproclassic.server.eisconnector.IPCEEISConnectionFactory;
import com.myproclassic.server.eisconnector.PCEEISConnectionException;
import com.myproclassic.server.eisconnector.PCEEISConnectorData;
import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.impl.StandardFileSystemManager;


class NonManagedTest
{
	PCEManagedConnectionFactorySFTP m_mcf = null;
    PCEResourceAdapterSFTP m_ra = null;
    byte[] m_message = "|*0123456789*|".getBytes();

	void runOutbound() throws Exception
	{
//        initMCF();
        IPCEEISConnectionFactory cf = (IPCEEISConnectionFactory) m_mcf.createConnectionFactory();
		IPCEEISConnection con = null;
		PCEEISConnectorData request = null;
		PCEEISConnectorData response = null;

		request = new PCEEISConnectorData();
        request.setTimeout(7000);
        
        request.setMessage(m_message);
        
        Hashtable<String, String> hashtable = new Hashtable<String, String>();
        
        // on Apache servers always accessible = HELP
        // @see http://incubator.terra-intl.com/projects/ftpserver/site_cmd.html
        hashtable.put(PCEConfigurationHolderSFTP.SFTP_ADDTAG_FILENAME, "12345.Txt");
        
        request.setAdditionalData(hashtable);
        request.setTransactionNumber(345);
        request.setTransactionStepNumber(0);
        
        con = cf.getConnection();
        
        response = (PCEEISConnectorData) con.sendAndReceive(request);
        
        con.close();

		
//		PCEFTPWrapper ftpWrapper = new PCEFTPWrapper();
//		
//		ftpWrapper.setHost("ftp.wincor-nixdorf.com");
//		ftpWrapper.setUser("anonymous");
//		ftpWrapper.setPassword("");
//		
//		ftpWrapper.openFTPConnection();
        
//        FileInputStream fis = null;

		
//        PCEFTPClientWrapper pceftpClientWrapper = new PCEFTPClientWrapper();
//        
//        pceftpClientWrapper.open("localhost");
//        
//        fis = new FileInputStream("d:\\Stuff\\fotos\\IMG_9218.JPG");
//        
//        pceftpClientWrapper.send("xyz_kai.jpg", fis);
//        
//        pceftpClientWrapper.close();
        
        
        

//        request = new PCEEISConnectorData();
//        request.setTimeout(7000); //PCEEISConnectorData.TIMEOUT_UNLIMITED);
//        request.setMessage(m_message);
//        request.setTransactionNumber(345);
//        request.setTransactionStepNumber(0);
//
//        PCEConnectionRequestInfoFTP cri = new PCEConnectionRequestInfoFTP();
////        cri.setURI("/cms/Products/Service_Sales/News");
////        cri.setURI("http://localhost:8081/Echo/echo");
////        cri.setURI("https://localhost:8443/Echo/echo");
//        cri.setURI("http://intranet.wincor-nixdorf.com:80/cms/_internal/Homepage_DE");
////        cri.setURI("https://bankingportal.sparkasse-paderborn.de/47250101/inetport/IPSTANDARD/REL4/gifs/headline_willkommen.gif");
//
//        
////        cri.setURI("https://www.heise.de:443"); 
//        cri.setContentType("application/x-www-form-urlencoded");
//        cri.setSendMethod("GET");        
//
//        con = cf.getConnection(cri);
//        request.setMessage("MerchantID=wincor_nixdorf&Len=125&Data=EFBEB56D756A0226F3AEF174E68837167BA45B02AE75C619163E81A7A79EF448DC647115EF4ABE99C2D2CE22ECAFBCDE368CE60B6E551D5C8A698168462D860CD23B09F868AF10FA1B1FC33B22CC67BB4EE717200B45BB9B1AF2035E63FA58D33854F59ED27B9794CA227C8924812811A33593916110244A41DD5BD88CD5B421".getBytes());
//        response = con.sendAndReceive(request);
//        con.close();
//        System.out.println("Received: " + new String(response.getMessage()));
//
//        con = cf.getConnection(cri);
//        request.setMessage("MerchantID=wincor_nixdorf&Len=125&Data=EFBEB56D756A0226F3AEF174E68837167BA45B02AE75C619163E81A7A79EF448DC647115EF4ABE99C2D2CE22ECAFBCDE368CE60B6E551D5C8A698168462D860CD23B09F868AF10FA1B1FC33B22CC67BB4EE717200B45BB9B1AF2035E63FA58D33854F59ED27B9794CA227C8924812811A33593916110244A41DD5BD88CD5B421".getBytes());
//        response = con.sendAndReceive(request);
//        System.out.println("Received: " + new String(response.getMessage()));
//        con.close();        
	}

    void initMCF() throws Exception 
    {
        m_ra = new PCEResourceAdapterSFTP();
        
        m_mcf = new PCEManagedConnectionFactorySFTP();
        m_mcf.setResourceAdapter(m_ra);

        //m_mcf.setProtocol("bla");
        m_mcf.setTimeout(new Long(32000L));
        m_mcf.setRetryInterval(new Integer(300));
        
        
        //m_mcf.setServerName("localhost");
        m_mcf.setServerName("0.0.0.0");
        m_mcf.setPortNumber(new Integer(22));
        //m_mcf.setFtpUsername("testuser");
        //m_mcf.setFtpPassword("testuser");
        m_mcf.setSftpUsername("user");
//        m_mcf.setSftpPassword("5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8");
        m_mcf.setSftpPassword("password");
        //m_mcf.setFtpDirectory("c:\\temp");
        m_mcf.setSftpDirectory("");
        m_mcf.setSSHAuthentication(false);
        
        //m_mcf.setFtpFileType(0);
        
        
        //m_mcf.setTransferMode("active");
        
//        m_mcf.setLocalAddress("depb1928");


        m_mcf.setAsyncConnect(new Boolean(false));
        m_mcf.setJCATrace(new Boolean(true));
        m_mcf.setLogWriter(new PrintWriter(System.out, true));

//        m_mcf.setProxyServerName("proxy-pdb.wincor-nixdorf.com");
//        m_mcf.setProxyServerName("plaxi.wincor-nixdorf.com");
//        m_mcf.setProxyPortNumber(new Integer(81));
//        m_mcf.setHttpVersion("HTTP/1.1");
//        m_mcf.setSendMethod("GET");
//        m_mcf.setContentType("jjjzutz");
//        m_mcf.setConnectMode(new Integer(3));
////        m_mcf.setURI("http://intranet.wincor-nixdorf.com/cms/_internal/Homepage_DE");///search?sourceid=navclient&aq=t&hl=de&ie=UTF-8&rls=GGLD,GGLD:2005-20,GGLD:de&q=java+tcp+io+streams");
    }

    public static void main(String[] args)
    {
        boolean isOutbound = true;
        if (args.length > 0 && "inbound".equalsIgnoreCase(args[0]))
        {
            isOutbound = false;
            System.out.println("START INBOUND");
        }
        else
        {
            System.out.println("START OUTBOUND");            
        }
        
        try
        {
            NonManagedTest instance = new NonManagedTest();
            instance.initMCF();
            if (isOutbound)
            {
                instance.runOutbound();
            }
            else
            {
                /// TODO kb add method runInbound
            	//instance.runInbound();
            }
            System.out.println("END");
        }
        catch (Exception e)
        {
            System.out.println("Should not occur");
            e.printStackTrace();
            ((PCEEISConnectionException) e).getOriginalException().printStackTrace();
        }
    }
 }




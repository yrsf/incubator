# May contain the following methods:
# def predeploy(appname)
# def postdeploy(appname)

def postdeploy(appname):
    createJ2CCF( appname, "SDPEISConnectorSFTP", "SDPEISConnectorSFTP", "SDPEISConnectorSFTP")

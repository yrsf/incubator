/**
 * File: $RCSfile: SDPEISConnectorSFTPBase/src/com/myproclassic/server/eisconnector/sftp/PCESFTPConnectorErrorCodes.java $
 *
 * Copyright (c) 2001-2005 by Wincor Nixdorf International GmbH,
 * Heinz-Nixdorf-Ring 1, 33106 Paderborn, Germany
 *
 * This software is the confidential and proprietary information
 * of Wincor Nixdorf. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Wincor Nixdorf."
 */
package com.myproclassic.server.eisconnector.sftp;

import com.myproclassic.server.eisconnector.IPCEEISConnectorErrorCodes;


public interface PCESFTPConnectorErrorCodes extends IPCEEISConnectorErrorCodes {

    public static final int SFTP_OKAY = 0;

    public static final int SFTP_ERR_COPY_FILE = 1031001;
    public static final int SFTP_ERR_CREATE_TEMP_FILE = 1031002;

}




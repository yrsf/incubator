/**
 * File: $RCSfile: SDPEISConnectorSFTPBase/src/com/myproclassic/server/eisconnector/sftp/PCESFTPConnection.java $
 *
 * Copyright (c) 2001-2005 by Wincor Nixdorf International GmbH,
 * Heinz-Nixdorf-Ring 1, 33106 Paderborn, Germany
 *
 * This software is the confidential and proprietary information
 * of Wincor Nixdorf. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Wincor Nixdorf."
 */
package com.myproclassic.server.eisconnector.sftp;

import java.io.*;
import java.util.Hashtable;


import com.myproclassic.server.eisconnector.IPCEEISConnectorErrorCodes;
import com.myproclassic.server.eisconnector.PCEEISConnectionException;
import com.myproclassic.server.eisconnector.PCEEISConnectorData;
import com.myproclassic.server.eisconnector.PCEEISException;
import com.myproclassic.server.eisconnector.impl.PCEEISPhysicalConnection;
import com.myproclassic.server.eisconnector.impl.PCEEISUtils;
import org.apache.commons.vfs2.*;
import org.apache.commons.vfs2.impl.StandardFileSystemManager;
import org.apache.commons.vfs2.provider.sftp.SftpFileSystemConfigBuilder;


public class PCESFTPConnection extends PCEEISPhysicalConnection {
    /**
     * Version control.
     *
     * @excludeMember
     */
    public transient static final String PCE_VERSION_CONTROL = "@(#) $RCSfile: SDPEISConnectorSFTPBase/src/com/myproclassic/server/eisconnector/sftp/PCESFTPConnection.java $, $Revision: 1.3 $, $Date: 2015/02/19 12:57:42MEZ $";

    public static final String TEMP_FILE_PREFIX = "pceByteStream";

    public static final String TEMP_FILE_SUFFIX = ".tmp";

    protected StandardFileSystemManager manager;

    /**
     * Holds a configuration property.
     */
    protected String m_serverName;
    /**
     * Holds a configuration property.
     */
    protected int m_portNumber;

    /**
     * Holds a configuration property.
     */
    protected String m_sftpUsername;
    /**
     * Holds a configuration property.
     */
    protected String m_sftpPassword;

    /**
     * Holds a configuration property.
     */
    protected String m_sftpDirectory;

    /**
     * Holds a configuration property.
     */
    protected Boolean m_SSHAuthentication;

    /**
     * Holds a configuration property.
     */
    protected String m_SSHKeyPath;
    /**
     * Constructor.
     *
     * @param config http configuration
     */
    public PCESFTPConnection(PCEConfigurationHolderSFTP config) {
        super(config);
        if (m_context.getTrace().isTrace()) {
            m_context.getTrace().traceConstructor(this, new String[]{config.getResourceAdapterMetaData().getConfigProperties().toString()});
        }

        updateConfig(config);
    }

    /**
     * Update configuration.
     *
     * @param config http configuration
     */
    public void updateConfig(PCEConfigurationHolderSFTP config) {

        m_serverName = config.getServerName();
        m_portNumber = config.getPortNumber();

        m_sftpUsername = config.getSftpUsername();
        m_sftpPassword = config.getSftpPassword();

        if(config.getSftpDirectory() != null) {
            m_sftpDirectory = config.getSftpDirectory();
        } else {
            m_sftpDirectory = PCEConfigurationHolderSFTP.SFTP_DEFAULT_DIRECTORY;
        }

        m_SSHAuthentication = config.getSSHAuthentication();
        m_SSHKeyPath = config.getSSHKeyPath();
    }

    /**
     * Opens a SFTP connection.
     *
     * @throws PCEEISException the pCEEIS exception
     * @see com.myproclassic.server.eisconnector.impl.IPCEEISPhysicalConnection#open()
     */
    public void open() throws PCEEISException {
        if (m_context.getTrace().isTrace()) {
            m_context.getTrace().traceMethodEntry(this, "open", new String[]{m_serverName,});
        }

//        try {
            manager = new StandardFileSystemManager();
//            manager.init();
//        } catch (FileSystemException e) {
//            if (m_context.getTrace().isTrace()) {
//                m_context.getTrace().traceException(this, "receive", e);
//            }
//            throw new PCEEISConnectionException(PCESFTPConnectorErrorCodes.PCE_ERR_CONNECTION, null, "Cannot open FS manager");
//        }

        if (m_context.getTrace().isTrace()) {
            m_context.getTrace().traceMethodExit(this, "open", null);
        }
    }

    /**
     * Closes a SFTP connection.
     */
    public void close() {
        if (m_context.getTrace().isTrace()) {
            m_context.getTrace().traceMethodEntry(this, "close", null);
        }

        manager.close();

        if (m_context.getTrace().isTrace()) {
            m_context.getTrace().traceMethodExit(this, "close", null);
        }
    }


    /**
     * Dispose.
     *
     * @see com.myproclassic.server.eisconnector.impl.IPCEEISPhysicalConnection#dispose()
     */
    public void dispose() {
        close();
        super.dispose();
    }

    /**
     * Send and receive.
     *
     * @param request the request
     * @return the EIS connector data
     * @throws PCEEISException the pCEEIS exception
     * @see com.myproclassic.server.eisconnector.impl.IPCEEISPhysicalConnection#sendAndReceive(com.myproclassic.server.eisconnector.PCEEISConnectorData)
     */
    public PCEEISConnectorData sendAndReceive(PCEEISConnectorData request) throws PCEEISException {
        if (m_context.getTrace().isTrace()) {
            m_context.getTrace().traceMethodEntry(this, "sendAndReceive", new String[]{PCEEISUtils.dumpSend(request, m_config.getSendEncoding())});
        }

        send(request);
        receive(request);

        if (m_context.getTrace().isTrace()) {
            m_context.getTrace().traceMethodExit(this, "sendAndReceive", PCEEISUtils.dumpReceive(request, m_config.getReceiveEncoding()));
        }
        return request;
    }

    /**
     * Cast additional data from PCEEISConnectorData to a hashtable and check for mandatory parameters.
     *
     * @param additionalData the additional data from from PCEEISConnectorData
     * @return hashtable casted parameters form additional data
     * @throws PCEEISException the pCEEIS exception
     */
    @SuppressWarnings("unchecked")
    protected Hashtable<String, String> checkAdditionalData(Object additionalData) throws PCEEISException {
        Hashtable<String, String> config = null;

        if (additionalData instanceof Hashtable<?, ?>) {

            try {
                config = (Hashtable<String, String>) additionalData;
            } catch (Exception e) {
                throw new PCEEISConnectionException(IPCEEISConnectorErrorCodes.PCE_ERR_CONNECTION, e, "AdditionalData error " + e.toString());
            }

        } else {
            throw new PCEEISConnectionException(IPCEEISConnectorErrorCodes.PCE_ERR_CONNECTION, null,
                    "AdditionalData is no hashtable with additional necessary parameters");
        }

        if (!config.containsKey(PCEConfigurationHolderSFTP.SFTP_ADDTAG_FILENAME)) {
            throw new PCEEISConnectionException(IPCEEISConnectorErrorCodes.PCE_ERR_CONNECTION, null, "No parameter "
                    + PCEConfigurationHolderSFTP.SFTP_ADDTAG_FILENAME + " in AdditionalData hashtable");
        }

        return config;
    }

    /**
     * PCEEISConnector Send request.
     *
     * @param request PCEEISConnectorData with send parameters in AdditionalData
     * @return the PCEEISConnectorData
     * @throws PCEEISException the PCE EIS exception with PCE error code
     * @see com.myproclassic.server.eisconnector.impl.IPCEEISPhysicalConnection#send(com.myproclassic.server.eisconnector.PCEEISConnectorData)
     */
    public PCEEISConnectorData send(PCEEISConnectorData request) throws PCEEISException {
        if (m_context.getTrace().isTrace()) {
            m_context.getTrace().traceMethodEntry(this, "send", new String[]{PCEEISUtils.dumpSend(request, m_config.getSendEncoding())});
        }
        Hashtable<String, String> sendConfig = null;

        try {
            manager.init();
            sendConfig = checkAdditionalData(request.getAdditionalData());

            if (!sendConfig.containsKey(PCEConfigurationHolderSFTP.SFTP_ADDTAG_FILENAME)) {
                throw new PCEEISConnectionException(IPCEEISConnectorErrorCodes.PCE_ERR_CONNECTION, null, "Expected parameter "
                        + PCEConfigurationHolderSFTP.SFTP_ADDTAG_FILENAME + " not found in AdditionalData");
            }
            FileObject remoteFile = manager.resolveFile(createConnectionString(sendConfig), createDefaultOptions());
            FileObject streamFile = manager.resolveFile(createTempFileFromByteArray(request.getMessage()).getAbsolutePath());
            remoteFile.copyFrom(streamFile, Selectors.SELECT_SELF);
            request.setCommunicationState(PCESFTPConnectorErrorCodes.SFTP_OKAY);
        } catch (PCEEISException e) {
            if (m_context.getTrace().isTrace()) {
                m_context.getTrace().traceException(this, "send", e);
            }
            request.setCommunicationState(PCESFTPConnectorErrorCodes.PCE_ERR_CONNECTION);
            throw new PCEEISConnectionException(PCESFTPConnectorErrorCodes.PCE_ERR_CONNECTION, e, "send error");
        } catch (FileSystemException e) {
            if (m_context.getTrace().isTrace()) {
                m_context.getTrace().traceException(this, "send", e);
            }
            request.setCommunicationState(PCESFTPConnectorErrorCodes.SFTP_ERR_COPY_FILE);
            throw new PCEEISConnectionException(PCESFTPConnectorErrorCodes.SFTP_ERR_COPY_FILE, e, "send error");
        } catch (IOException e) {
            if (m_context.getTrace().isTrace()) {
                m_context.getTrace().traceException(this, "send", e);
            }
            request.setCommunicationState(PCESFTPConnectorErrorCodes.SFTP_ERR_CREATE_TEMP_FILE);
            throw new PCEEISConnectionException(PCESFTPConnectorErrorCodes.SFTP_ERR_CREATE_TEMP_FILE, e, "send error");
        } finally {
            manager.close();
        }

        if (m_context.getTrace().isTrace()) {
            m_context.getTrace().traceMethodExit(this, "send", null);
        }
        return request;
    }

    public FileSystemOptions createDefaultOptions() throws FileSystemException {
        FileSystemOptions opts = new FileSystemOptions();
        if (m_SSHAuthentication) {
            SftpFileSystemConfigBuilder.getInstance().setIdentities(opts, new File[]{new File(m_SSHKeyPath)});
        } else {
            SftpFileSystemConfigBuilder.getInstance().setStrictHostKeyChecking(opts, "no");
        }
        return opts;
    }

    /**
     * PCEEISConnector Receive.
     *
     * @param selector the selector with receive parameters in AdditionalData
     * @return the PCEEISConnectorData
     * @throws PCEEISException the PCE EIS exception with PCE error code
     * @see com.myproclassic.server.eisconnector.impl.IPCEEISPhysicalConnection#receive(com.myproclassic.server.eisconnector.PCEEISConnectorData)
     */
    public PCEEISConnectorData receive(PCEEISConnectorData selector) throws PCEEISException {
        if (m_context.getTrace().isTrace()) {
            m_context.getTrace().traceMethodEntry(this, "receive", null);
        }
        if (selector == null) {
            selector = new PCEEISConnectorData();
        }

        Hashtable<String, String> sendConfig = null;

        try {
            manager.init();
            sendConfig = checkAdditionalData(selector.getAdditionalData());

            FileObject remoteFile = manager.resolveFile(createConnectionString(sendConfig), createDefaultOptions());
            FileObject streamFile = manager.resolveFile(createTempFile().getAbsolutePath());
            streamFile.copyFrom(remoteFile, Selectors.SELECT_SELF);
            selector.setMessage(getMessageFromFileObject(streamFile));
            selector.setCommunicationState(PCESFTPConnectorErrorCodes.SFTP_OKAY);

        } catch (FileSystemException e) {
            if (m_context.getTrace().isTrace()) {
                m_context.getTrace().traceException(this, "receive", e);
            }
            selector.setCommunicationState(PCESFTPConnectorErrorCodes.SFTP_ERR_COPY_FILE);
            throw new PCEEISConnectionException(PCESFTPConnectorErrorCodes.SFTP_ERR_COPY_FILE, null, "receive error");
        } catch (IOException e) {
            if (m_context.getTrace().isTrace()) {
                m_context.getTrace().traceException(this, "receive", e);
            }
            selector.setCommunicationState(PCESFTPConnectorErrorCodes.SFTP_ERR_CREATE_TEMP_FILE);
            throw new PCEEISConnectionException(PCESFTPConnectorErrorCodes.SFTP_ERR_CREATE_TEMP_FILE, null, "receive error");
        } finally {
            manager.close();
        }

        if (m_context.getTrace().isTrace()) {
            m_context.getTrace().traceMethodExit(this, "receive", PCEEISUtils.dumpReceive(selector, m_config.getReceiveEncoding()));
        }
        return selector;
    }

    /**
     * Checks if is okay.
     *
     * @return true, if is okay
     * @see com.myproclassic.server.eisconnector.impl.IPCEEISPhysicalConnection#isOkay()
     */
    public boolean isOkay() {
        return true;
    }

    private String createConnectionString(Hashtable<String, String> sendConfig) {

        String filePath = m_sftpDirectory.concat(sendConfig.get(PCEConfigurationHolderSFTP.SFTP_ADDTAG_FILENAME));
        String hostName = m_serverName.concat(":").concat(String.valueOf(m_portNumber));
        String conString;
        if (m_SSHAuthentication) {
            conString =  "sftp://" + m_sftpUsername + "@" + hostName + "/" + filePath;
        } else {
            conString =  "sftp://" + m_sftpUsername + ":" + m_sftpPassword + "@" + hostName + "/" + filePath;
        }

        return conString;
    }

    private File createTempFileFromByteArray(byte[] message) throws IOException {
        File file = File.createTempFile(TEMP_FILE_PREFIX, TEMP_FILE_SUFFIX);
        file.deleteOnExit();
        FileOutputStream fos = new FileOutputStream(file);
        fos.write(message);
        return file;
    }

    private File createTempFile() throws IOException {
        File file = File.createTempFile(TEMP_FILE_PREFIX, TEMP_FILE_SUFFIX);
        file.deleteOnExit();
        return file;
    }

    private byte[] getMessageFromFileObject(FileObject file) throws IOException {
        InputStream in = file.getContent().getInputStream();
        byte[] message = new byte[in.available()];
        in.read(message);
        in.close();
        return message;
    }

}


/**
 * File: $RCSfile: SDPEISConnectorSFTPBase/src/com/myproclassic/server/eisconnector/sftp/PCEManagedConnectionFactorySFTP.java $
 *
 * Copyright (c) 2001-2005 by Wincor Nixdorf International GmbH,
 * Heinz-Nixdorf-Ring 1, 33106 Paderborn, Germany
 *
 * This software is the confidential and proprietary information
 * of Wincor Nixdorf. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Wincor Nixdorf."
 */
package com.myproclassic.server.eisconnector.sftp;

import java.io.PrintWriter;
import java.util.Set;

import javax.resource.ResourceException;
import javax.resource.spi.ConnectionManager;
import javax.resource.spi.ConnectionRequestInfo;
import javax.resource.spi.ManagedConnection;
import javax.resource.spi.ManagedConnectionFactory;
import javax.resource.spi.ResourceAdapter;
import javax.resource.spi.ResourceAdapterAssociation;
import javax.security.auth.Subject;

import com.myproclassic.server.eisconnector.impl.PCEEISContext;
import com.myproclassic.server.eisconnector.impl.PCEEISTrace;
import com.myproclassic.server.eisconnector.impl.PCEManagedConnectionFactoryDelegate;

public class PCEManagedConnectionFactorySFTP extends PCEConfigurationHolderSFTP implements ManagedConnectionFactory, ResourceAdapterAssociation
{
    private static final long serialVersionUID = 91784403974733023L;

    /**
     * Version control.
     * @excludeMember
     */
    public transient static final String PCE_VERSION_CONTROL = 
		"@(#) $RCSfile: SDPEISConnectorSFTPBase/src/com/myproclassic/server/eisconnector/sftp/PCEManagedConnectionFactorySFTP.java $, $Revision: 1.1 $, $Date: 2014/11/27 11:07:31MEZ $";

    /** Holds the association */
    protected ResourceAdapter resourceAdapter = null;
	private final PCEEISContext context;
	private final boolean isJca;
	private PCEManagedConnectionFactoryDelegate delegate;

	/** Constructor. */
	public PCEManagedConnectionFactorySFTP() {
		this(true);
	}

	/** Constructor. */
	public PCEManagedConnectionFactorySFTP(boolean isJca) {
		context = new PCEEISContext();
		this.isJca = isJca;
	}

	/** Constructor. */
	public PCEManagedConnectionFactorySFTP(PCEManagedConnectionFactoryDelegate delegate, PCEEISContext context) {
		this.delegate = delegate;
		this.context = context;
		this.isJca = false;
	}

	/* (non-Javadoc)
	 * @see javax.resource.spi.ManagedConnectionFactory#createConnectionFactory(javax.resource.spi.ConnectionManager)
	 */
	@Override
	public Object createConnectionFactory(ConnectionManager connectionManager) throws ResourceException {
		return getDelegate().createConnectionFactory(this, connectionManager);
	}

	/* (non-Javadoc)
	 * @see javax.resource.spi.ManagedConnectionFactory#createConnectionFactory()
	 */
	@Override
	public Object createConnectionFactory() throws ResourceException {
		return getDelegate().createConnectionFactory(this);
	}

	/* (non-Javadoc)
	 * @see javax.resource.spi.ManagedConnectionFactory#createManagedConnection(javax.security.auth.Subject, javax.resource.spi.ConnectionRequestInfo)
	 */
	@Override
	public ManagedConnection createManagedConnection(Subject subject, ConnectionRequestInfo info) throws ResourceException {
		return getDelegate().createManagedConnection(this, subject, info);
	}

	@SuppressWarnings("rawtypes")
	@Override
	public ManagedConnection matchManagedConnections(Set connectionSet, Subject subject, ConnectionRequestInfo cri) throws ResourceException {
		return getDelegate().matchManagedConnections(this, connectionSet, subject, cri);
	}

	/* (non-Javadoc)
	 * @see javax.resource.spi.ManagedConnectionFactory#setLogWriter(java.io.PrintWriter)
	 */
	@Override
	public void setLogWriter(PrintWriter logWriter) throws ResourceException {
		if (getJCATrace() != null) {
			getContext().setJCATrace(getJCATrace().booleanValue());
		}
		getTrace().setPrintWriter(logWriter);
	}

	/* (non-Javadoc)
	 * @see javax.resource.spi.ManagedConnectionFactory#getLogWriter()
	 */
	@Override
	public PrintWriter getLogWriter() throws ResourceException {
		return getTrace().getPrintWriter();
	}

	/* (non-Javadoc)
	 * @see javax.resource.spi.ResourceAdapterAssociation#setResourceAdapter(javax.resource.spi.ResourceAdapter)
	 */
	@Override
	public void setResourceAdapter(ResourceAdapter resourceAdapter) throws ResourceException {
		this.resourceAdapter = resourceAdapter;
		if (resourceAdapter instanceof PCEResourceAdapterSFTP) {
			setParent((PCEResourceAdapterSFTP) resourceAdapter);
		}
	}

	/* (non-Javadoc)
	 * @see javax.resource.spi.ResourceAdapterAssociation#getResourceAdapter()
	 */
	@Override
	public ResourceAdapter getResourceAdapter() {
		return resourceAdapter;
	}

	/** @return generic managed connection factory delegate */
	private PCEManagedConnectionFactoryDelegate getDelegate() {
		if (delegate == null) {
			delegate = new PCEManagedConnectionFactoryDelegate(this, context, isJca);
		}
		return delegate;
	}

	public void setDelegate(PCEManagedConnectionFactoryDelegate delegate) {
		this.delegate = delegate;
	}

	/** @return trace */
	private PCEEISTrace getTrace() {
		return context.getTrace();
	}

	public PCEEISContext getContext() {
		return context;
	}
	
}

